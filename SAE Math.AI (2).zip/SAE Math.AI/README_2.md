# SAE Math.AI 🤖➗

SAE Math.AI ialah aplikasi pembantu matematik sekolah rendah menggunakan Python dan Streamlit. Ia boleh menyelesaikan pelbagai soalan termasuk:
- Pecahan
- Perpuluhan
- Peratus
- Nisbah
- Pembundaran

🖼 Logo: ![SAE Logo](logo.png)

## Cara Guna
1. Buka terminal dan taip:

2. Aplikasi web akan dibuka dalam pelayar anda.

## Dicipta oleh
- S, A, E (Kumpulan Projek AI)

## Lesen
Projek ini adalah untuk tujuan pendidikan dan pertandingan.
